/**
 * Web Dashboard & Control Server for Render.com
 * Provides /qr web route to link WhatsApp, live lead queue controls, and status monitoring
 */

require('dotenv').config();

// Global Process Crash Shield (Protects Render container from ever crashing on unhandled errors)
process.on('uncaughtException', (err) => {
  console.error('🛡️ [Crash Shield - Uncaught Exception]:', err.message);
});
process.on('unhandledRejection', (reason) => {
  console.error('🛡️ [Crash Shield - Unhandled Rejection]:', reason);
});

const express = require('express');
const path = require('path');
const whatsapp = require('./whatsapp');
const scraper = require('./scraper');
const queue = require('./queue');

const app = express();
const PORT = process.env.PORT || 3001;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Anti-Sleep Keep-Alive State & Auto-Host Detection
let detectedBaseUrl = (process.env.RENDER_EXTERNAL_URL || process.env.PUBLIC_URL || '').replace(/\/$/, '');
let keepAliveTimer = null;
let lastPingStatus = 'Pending first ping';
let lastPingTime = 'Never';

function startKeepAliveEngine(targetUrl) {
  if (!targetUrl || keepAliveTimer) return;
  detectedBaseUrl = targetUrl.replace(/\/$/, '');
  console.log(`📡 [Anti-Sleep Keep-Alive] Engaged for: ${detectedBaseUrl}`);
  console.log(`⏱️ [Anti-Sleep Keep-Alive] Pinging ${detectedBaseUrl}/ping every 3 minutes to stop Render Free sleep.`);

  const runPing = async () => {
    try {
      const res = await fetch(`${detectedBaseUrl}/ping`, {
        headers: { 'User-Agent': 'Render-AntiSleep-Heartbeat/3.0' },
        signal: AbortSignal.timeout(10000)
      });
      lastPingStatus = `HTTP ${res.status} OK`;
      lastPingTime = new Date().toLocaleTimeString('en-IN', { timeZone: 'Asia/Kolkata', hour: '2-digit', minute: '2-digit', second: '2-digit' }) + ' IST';
      console.log(`💓 [Anti-Sleep Heartbeat] Pinged ${detectedBaseUrl}/ping -> ${lastPingStatus} at ${lastPingTime}`);
    } catch (err) {
      lastPingStatus = `Warn: ${err.message}`;
      console.warn('⚠️ [Heartbeat Notice]:', err.message);
    }
  };

  // Immediate ping after 5 seconds, then every 3 minutes (180,000 ms)
  setTimeout(runPing, 5000);
  keepAliveTimer = setInterval(runPing, 3 * 60 * 1000);
}

// Inbound Request Sniffer: auto-captures domain on Render even if env var was omitted
app.use((req, res, next) => {
  if (!detectedBaseUrl) {
    const proto = req.headers['x-forwarded-proto'] || 'https';
    const host = req.headers['x-forwarded-host'] || req.headers['host'] || req.get('host');
    if (host && !host.includes('localhost') && !host.includes('127.0.0.1')) {
      const resolved = `${proto}://${host}`;
      console.log(`🌐 [Host Auto-Detected] Inbound host captured: ${resolved}`);
      startKeepAliveEngine(resolved);
    }
  }
  next();
});

// Ultra-fast Render Health Check Endpoints (Guarantees Render never restarts container)
app.get('/healthz', (req, res) => res.status(200).send('OK'));
app.get('/ping', (req, res) => res.status(200).send('pong'));

/**
 * Live QR Scan Page (/qr)
 */
app.get('/qr', (req, res) => {
  const isConnected = whatsapp.isConnected();
  const phone = whatsapp.getConnectedNumber();
  const qrDataUrl = whatsapp.getQrCodeDataUrl();

  let htmlContent = '';

  if (isConnected) {
    htmlContent = `
      <div class="card connected">
        <div class="icon">✅</div>
        <h2>WhatsApp Connected!</h2>
        <p class="phone">+${phone}</p>
        <p class="desc">Your WhatsApp account is linked and actively processing leads.</p>
        <a href="/" class="btn">Go to Dashboard</a>
      </div>
    `;
  } else if (qrDataUrl) {
    htmlContent = `
      <div class="card">
        <h2>Scan QR with WhatsApp</h2>
        <p class="subtitle">Open WhatsApp > Linked Devices > Link a Device</p>
        <div class="qr-box">
          <img src="${qrDataUrl}" alt="WhatsApp QR Code" class="qr-img" />
        </div>
        <p class="refresh-hint">This page auto-refreshes every 5 seconds.</p>
      </div>
      <script>
        setTimeout(() => { window.location.reload(); }, 5000);
      </script>
    `;
  } else {
    htmlContent = `
      <div class="card">
        <div class="spinner"></div>
        <h2>Initializing WhatsApp Socket...</h2>
        <p class="desc">Generating a new QR code, please wait a few seconds...</p>
      </div>
      <script>
        setTimeout(() => { window.location.reload(); }, 4000);
      </script>
    `;
  }

  res.send(`
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>WhatsApp Web QR Link - Bemisaal Bot</title>
      <style>
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
        body { background: #0f172a; color: #fff; min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 1.5rem; }
        .card { background: #1e293b; border: 1px solid #334155; border-radius: 20px; padding: 2.5rem 2rem; max-width: 440px; width: 100%; text-align: center; box-shadow: 0 20px 40px rgba(0,0,0,0.5); }
        .card.connected { border-color: #059669; }
        h2 { font-size: 1.5rem; margin-bottom: 0.5rem; color: #f8fafc; }
        .subtitle { color: #94a3b8; font-size: 0.9rem; margin-bottom: 1.5rem; }
        .qr-box { background: #fff; padding: 1rem; border-radius: 16px; display: inline-block; margin-bottom: 1.25rem; }
        .qr-img { width: 260px; height: 260px; display: block; }
        .phone { font-size: 1.25rem; font-weight: 700; color: #34d399; margin: 0.5rem 0 1rem; }
        .desc { color: #94a3b8; font-size: 0.95rem; line-height: 1.5; margin-bottom: 1.5rem; }
        .btn { display: inline-block; background: #059669; color: #fff; text-decoration: none; padding: 0.75rem 1.5rem; border-radius: 10px; font-weight: 600; }
        .btn:hover { background: #10b981; }
        .icon { font-size: 3rem; margin-bottom: 1rem; }
        .refresh-hint { font-size: 0.8rem; color: #64748b; }
        .spinner { width: 44px; height: 44px; border: 4px solid #334155; border-top-color: #34d399; border-radius: 50%; animation: spin 1s infinite linear; margin: 0 auto 1.5rem; }
        @keyframes spin { 100% { transform: rotate(360deg); } }
      </style>
    </head>
    <body>
      ${htmlContent}
    </body>
    </html>
  `);
});

/**
 * Main Web Dashboard (/)
 */
app.get('/', (req, res) => {
  const isConnected = whatsapp.isConnected();
  const phone = whatsapp.getConnectedNumber();
  const state = queue.getQueueState();
  const scraperStats = scraper.getScraperStats();
  const totalShielded = scraper.getTotalShieldedCount ? scraper.getTotalShieldedCount() : 0;
  const hotLeads = scraper.getHotRepliedLeads ? scraper.getHotRepliedLeads() : [];

  res.send(`
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta http-equiv="refresh" content="8">
      <title>Webify AI Lead & Website Outreach Bot</title>
      <style>
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
        body { background: #090d16; color: #f1f5f9; padding: 1.5rem; }
        .container { max-width: 800px; margin: 0 auto; }
        header { display: flex; align-items: center; justify-content: space-between; border-bottom: 1px solid #1e293b; padding-bottom: 1.25rem; margin-bottom: 2rem; }
        h1 { font-size: 1.5rem; color: #38bdf8; }
        .status-badge { display: inline-flex; align-items: center; gap: 0.5rem; padding: 0.4rem 0.9rem; border-radius: 9999px; font-size: 0.85rem; font-weight: 700; }
        .status-badge.online { background: #064e3b; color: #6ee7b7; border: 1px solid #059669; }
        .status-badge.offline { background: #7f1d1d; color: #fca5a5; border: 1px solid #dc2626; }
        .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 1rem; margin-bottom: 2rem; }
        .stat-card { background: #131c2e; border: 1px solid #1e293b; border-radius: 14px; padding: 1.25rem; text-align: center; }
        .stat-val { font-size: 1.8rem; font-weight: 800; color: #38bdf8; margin-top: 0.35rem; }
        .stat-label { font-size: 0.8rem; color: #94a3b8; text-transform: uppercase; letter-spacing: 0.05em; }
        .section-box { background: #131c2e; border: 1px solid #1e293b; border-radius: 14px; padding: 1.5rem; margin-bottom: 1.5rem; }
        h3 { font-size: 1.1rem; margin-bottom: 1rem; color: #f8fafc; }
        .btn-group { display: flex; gap: 0.75rem; flex-wrap: wrap; }
        .btn { padding: 0.65rem 1.25rem; border-radius: 8px; font-weight: 600; text-decoration: none; border: none; cursor: pointer; font-size: 0.9rem; }
        .btn-green { background: #0284c7; color: #fff; }
        .btn-blue { background: #2563eb; color: #fff; }
        .btn-outline { background: transparent; border: 1px solid #334155; color: #cbd5e1; }
        textarea { width: 100%; height: 90px; background: #090d16; border: 1px solid #334155; border-radius: 8px; color: #fff; padding: 0.75rem; font-size: 0.9rem; margin-bottom: 0.75rem; resize: vertical; }
        .log-box { background: #090d16; padding: 1rem; border-radius: 8px; font-family: monospace; font-size: 0.85rem; color: #94a3b8; }
      </style>
    </head>
    <body>
      <div class="container">
        <header>
          <div>
            <h1>Bemisaal Wellness — Lead & Consultation Bot</h1>
            <p style="color: #64748b; font-size: 0.85rem; margin-top: 0.2rem;">Ayurvedic &amp; Unani Shahi Majoon • Discreet COD All India • Helpline: 9990394794</p>
          </div>
          <div>
            ${isConnected ?
              `<span class="status-badge online">● Connected: +${phone}</span>` :
              `<a href="/qr" class="status-badge offline" style="text-decoration: none;">⚠️ Scan QR Code</a>`
            }
          </div>
        </header>

        <div class="grid">
          <div class="stat-card">
            <div class="stat-label">Batch Progress</div>
            <div class="stat-val" style="color: #38bdf8;">${state.currentBatchCount} / ${state.batchSize}</div>
          </div>
          <div class="stat-card">
            <div class="stat-label">Today's Anti-Ban Cap</div>
            <div class="stat-val" style="color: #34d399;">${state.dailySentCount} / ${state.dailyMaxLeads}</div>
          </div>
          <div class="stat-card">
            <div class="stat-label">Total Sent (All Time)</div>
            <div class="stat-val">${state.totalSentDb}</div>
          </div>
          <div class="stat-card">
            <div class="stat-label">Leads In Queue</div>
            <div class="stat-val" style="color: #fbbf24;">${state.queuedRemaining}</div>
          </div>
          <div class="stat-card">
            <div class="stat-label">Shielded Past Leads</div>
            <div class="stat-val" style="color: #a855f7;">${totalShielded}</div>
          </div>
          <div class="stat-card" style="border-color: #f43f5e33;">
            <div class="stat-label" style="color: #fda4af;">Hot Leads (Replied)</div>
            <div class="stat-val" style="color: #f43f5e;">${hotLeads.length}</div>
          </div>
        </div>

        ${req.query.shielded ? `
          <div style="background: #1e1b4b; border: 1px solid #8b5cf6; border-radius: 12px; padding: 1.1rem; margin-bottom: 1.5rem; color: #e9d5ff;">
            🛡️ <strong>Older Bot Shield Updated!</strong> Permanently shielded <strong>${req.query.count || 0}</strong> numbers from ever receiving outreach again.
          </div>
        ` : ''}

        <!-- Hot Leads Section with 1-Click CSV Export -->
        <div class="section-box" style="border-left: 4px solid #f43f5e; background: #88133712;">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.75rem; flex-wrap: wrap; gap: 0.5rem;">
            <div>
              <h3 style="margin: 0; color: #fb7185;">🔥 Hot Replied Leads (${hotLeads.length})</h3>
              <p style="color: #94a3b8; font-size: 0.85rem; margin-top: 0.2rem;">Patients who engaged with consultation outreach. Ready to close via WhatsApp.</p>
            </div>
            <a href="/api/leads/export-csv" class="btn" style="background: #e11d48; color: #fff; font-weight: 700; text-decoration: none;">📥 Download Leads (.CSV)</a>
          </div>
          ${hotLeads.length === 0 ? '<p style="color: #64748b; font-size: 0.85rem;">No replies yet today. As soon as leads respond, they appear here instantly.</p>' : `
            <div style="max-height: 220px; overflow-y: auto; background: #090d16; border-radius: 8px; padding: 0.5rem;">
              ${hotLeads.slice(-10).reverse().map(l => `
                <div style="display: flex; justify-content: space-between; align-items: center; padding: 0.5rem; border-bottom: 1px solid #1e293b;">
                  <div>
                    <strong style="color: #f1f5f9;">+${l.phone}</strong>
                    <span style="color: #64748b; font-size: 0.8rem; margin-left: 0.5rem;">${l.name || 'Valued Patient'}</span>
                  </div>
                  <a href="https://wa.me/${l.phone}" target="_blank" class="btn btn-green" style="padding: 0.35rem 0.75rem; font-size: 0.8rem; text-decoration: none;">💬 Open Chat</a>
                </div>
              `).join('')}
            </div>
          `}
        </div>

        <!-- Master Pause / Stop Bot Controls -->
        ${state.isPaused ? `
          <div style="background: #450a0a; border: 1px solid #b91c1c; border-radius: 12px; padding: 1.25rem; margin-bottom: 1.5rem; display: flex; align-items: center; justify-content: space-between; flex-wrap: gap: 1rem;">
            <div>
              <h3 style="color: #f87171; margin-bottom: 0.25rem;">🛑 Bot is STOPPED / PAUSED</h3>
              <p style="color: #fca5a5; font-size: 0.85rem; margin: 0;">Outreach is paused. All leads and queue positions are completely safe.</p>
            </div>
            <form method="POST" action="/api/queue/resume" style="margin: 0;">
              <button type="submit" class="btn" style="background: #16a34a; color: #fff; padding: 0.75rem 1.5rem; font-size: 0.95rem; font-weight: 700; cursor: pointer;">▶️ Resume Bot Now</button>
            </form>
          </div>
        ` : `
          <div style="background: #022c22; border: 1px solid #059669; border-radius: 12px; padding: 1.25rem; margin-bottom: 1.5rem; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 1rem;">
            <div>
              <h3 style="color: #34d399; margin-bottom: 0.25rem;">⚡ Bot is ACTIVE &amp; RUNNING (100% Real Human 50 Leads / Day Mode)</h3>
              <p style="color: #6ee7b7; font-size: 0.85rem; margin: 0;">100% Real Human Engine: 1 msg every 1–2 mins random jitter • Mini-batches of 5–8 leads • 50–80 min random tea breaks • Daytime IST active (9:00 AM – 9:30 PM) • 50 safe leads/day (${state.dailySentCount}/${state.dailyMaxLeads}) • Two-Step Conversational Shield (Zero Spam Reports).</p>
            </div>
            <form method="POST" action="/api/queue/pause" style="margin: 0;">
              <button type="submit" class="btn" style="background: #dc2626; color: #fff; padding: 0.75rem 1.5rem; font-size: 0.95rem; font-weight: 700; cursor: pointer;">🛑 Stop / Pause Bot</button>
            </form>
          </div>
        `}

        <div class="section-box">
          <h3>⚡ Live Queue Activity</h3>
          <p class="log-box">Status: <strong>${state.currentStatus}</strong><br>Next Action Scheduled: <strong>${state.nextActionTime || 'Processing'}</strong></p>
        </div>

        <div class="section-box">
          <h3>📥 Add Indian Mobile Numbers to Queue</h3>
          <form method="POST" action="/api/leads/add-form">
            <textarea name="numbers" placeholder="Paste Indian 10-digit mobile numbers or with 91 (e.g. 9876543210, 09876543210, +91 9876543210)..."></textarea>
            <div class="btn-group">
              <button type="submit" class="btn btn-green">+ Add to Health Lead Queue</button>
              <a href="/qr" class="btn btn-outline">📱 Scan / Reconnect WhatsApp</a>
            </div>
          </form>
        </div>

        <div class="section-box" style="border-left: 4px solid #a855f7;">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.5rem;">
            <h3 style="margin: 0; color: #c084fc;">🛡️ Shield Past Numbers (Older Bot Contacts / Blacklist)</h3>
            <span style="background: #581c87; color: #e9d5ff; font-size: 0.75rem; padding: 0.2rem 0.6rem; border-radius: 9999px; font-weight: 700;">DUPLICATE SHIELD</span>
          </div>
          <p style="color: #94a3b8; font-size: 0.85rem; margin-bottom: 0.75rem;">
            Paste numbers from your older bots, past campaigns, or spreadsheets below (one per line). They will be added to the permanent shield ledger so this bot <strong>never messages them again</strong>!
          </p>
          <form method="POST" action="/api/leads/shield-past">
            <textarea name="pastNumbers" placeholder="Paste older bot numbers here (one per line, e.g. 9876543210 or 919876543210)..."></textarea>
            <button type="submit" class="btn" style="background: #7c3aed; color: #fff; font-weight: 700; cursor: pointer;">🛡️ Permanently Shield These Numbers</button>
          </form>
        </div>

        <div class="section-box" style="border-color: #059669; background: #064e3b15;">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.5rem;">
            <h3 style="margin: 0; color: #34d399;">🌐 24/7 Autonomous Indian Health Scraper (100% Free)</h3>
            <span style="background: ${scraperStats.isPaused ? '#7f1d1d' : '#065f46'}; color: ${scraperStats.isPaused ? '#fca5a5' : '#a7f3d0'}; font-size: 0.75rem; padding: 0.2rem 0.6rem; border-radius: 9999px; font-weight: 700;">${scraperStats.isPaused ? 'PAUSED' : 'ACTIVE 24/7'}</span>
          </div>
          <p style="color: #94a3b8; font-size: 0.9rem; margin-bottom: 0.75rem;">Continuously sweeps major Indian cities (Delhi, Mumbai, Bangalore, Hyderabad, Jaipur, Lucknow, Patna, etc.) for high-intent wellness queries. Zero API cost.</p>
          <p class="log-box" style="margin-bottom: 0.75rem;">
            Status: <strong>${scraperStats.status}</strong><br>
            Sweeps Completed: <strong>${scraperStats.cyclesCompleted}</strong> | Session Harvested: <strong>${scraperStats.leadsHarvestedSession}</strong> | Total in DB: <strong>${scraperStats.totalInDb}</strong><br>
            Active Target: <strong>${scraperStats.lastScrapedCity ? scraperStats.lastScrapedCity.toUpperCase() + ' (' + scraperStats.lastScrapedNiche + ')' : 'India Metros'}</strong>
          </p>
          <div style="display: flex; gap: 0.75rem; flex-wrap: wrap;">
            <form method="POST" action="/api/scraper/trigger-free-form" style="margin: 0;">
              <button type="submit" class="btn btn-green">⚡ Run Extra Instant Sweep</button>
            </form>
            ${scraperStats.isPaused ? `
              <form method="POST" action="/api/scraper/resume" style="margin: 0;">
                <button type="submit" class="btn" style="background: #16a34a; color: #fff; cursor: pointer;">▶️ Resume Scraper</button>
              </form>
            ` : `
              <form method="POST" action="/api/scraper/pause" style="margin: 0;">
                <button type="submit" class="btn" style="background: #dc2626; color: #fff; cursor: pointer;">🛑 Stop / Pause Scraper</button>
              </form>
            `}
          </div>
        </div>

        <div class="section-box" style="border-left: 4px solid #38bdf8;">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.5rem;">
            <h3 style="margin: 0; color: #38bdf8;">🛡️ Render Anti-Sleep Shield (24/7 Always Awake)</h3>
            <span style="background: #0369a1; color: #e0f2fe; font-size: 0.75rem; padding: 0.2rem 0.6rem; border-radius: 9999px; font-weight: 700;">HEARTBEAT: ACTIVE</span>
          </div>
          <p style="color: #94a3b8; font-size: 0.85rem; margin-bottom: 0.75rem;">
            Pinging URL: <code style="color: #38bdf8;">${detectedBaseUrl ? detectedBaseUrl + '/ping' : 'Auto-detecting on first visit...'}</code><br>
            Heartbeat Status: <strong style="color: #34d399;">${lastPingStatus}</strong> (Last: ${lastPingTime}) | Interval: <strong>Every 3 minutes</strong>
          </p>
          <div style="background: #090d16; border: 1px solid #1e293b; border-radius: 8px; padding: 0.75rem; font-size: 0.8rem; color: #94a3b8;">
            💡 <strong>Bulletproof Tip:</strong> Add <code>${detectedBaseUrl ? detectedBaseUrl + '/healthz' : 'https://<your-render-url>/healthz'}</code> to free <a href="https://cron-job.org" target="_blank" style="color: #38bdf8; text-decoration: underline;">cron-job.org</a> or <a href="https://uptimerobot.com" target="_blank" style="color: #38bdf8; text-decoration: underline;">uptimerobot.com</a> (5 min interval) so external servers keep your bot running 24/7 non-stop!
          </div>
        </div>

        <div class="section-box">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.5rem;">
            <h3 style="margin: 0; color: #cbd5e1;">🔍 Apify Google Search (Ayurvedic &amp; Health Queries Backup)</h3>
            <span style="background: #334155; color: #94a3b8; font-size: 0.75rem; padding: 0.2rem 0.6rem; border-radius: 9999px; font-weight: 700;">API BACKUP</span>
          </div>
          <p style="color: #94a3b8; font-size: 0.9rem; margin-bottom: 1rem;">Searches recent (<30 days) Indian discussions for mardana kamzori, shighrapatan, and herbal treatment queries. Uses Apify credits if needed.</p>
          <form method="POST" action="/api/scraper/trigger-form">
            <button type="submit" class="btn btn-outline">Run Apify Health Search (Uses Apify Credits)</button>
          </form>
        </div>
            <span style="background: #334155; color: #94a3b8; font-size: 0.75rem; padding: 0.2rem 0.6rem; border-radius: 9999px; font-weight: 700;">API BACKUP</span>
          </div>
          <p style="color: #94a3b8; font-size: 0.9rem; margin-bottom: 1rem;">Runs Apify Google search actor searching global forums and social links. Uses your Apify API credits if needed.</p>
          <form method="POST" action="/api/scraper/trigger-form">
            <button type="submit" class="btn btn-outline">Run Apify Scraper (Uses Apify Credits)</button>
          </form>
        </div>
      </div>
    </body>
    </html>
  `);
});

/**
 * API Endpoints
 */
app.get('/api/status', (req, res) => {
  res.json({
    whatsapp: {
      connected: whatsapp.isConnected(),
      phone: whatsapp.getConnectedNumber()
    },
    queue: queue.getQueueState()
  });
});

app.get('/api/leads/export-csv', (req, res) => {
  const hotLeads = scraper.getHotRepliedLeads ? scraper.getHotRepliedLeads() : [];
  let csv = 'Phone,Name,Status,Updated_At,Direct_WhatsApp_Link\r\n';
  for (const l of hotLeads) {
    const phone = l.phone || '';
    const name = (l.name || 'Valued Patient').replace(/"/g, '""');
    const status = l.status || 'replied';
    const updated = l.updated_at ? new Date(l.updated_at).toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' }) : 'Recent';
    const waLink = `https://wa.me/${phone}`;
    csv += `+${phone},"${name}",${status},"${updated}","${waLink}"\r\n`;
  }
  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', 'attachment; filename="bemisaal_hot_leads.csv"');
  res.send(csv);
});

app.post('/api/leads/add-form', (req, res) => {
  const numbersText = req.body.numbers || '';
  const lines = numbersText.split('\n');
  const leads = [];

  for (const line of lines) {
    const trimmed = line.trim();
    if (trimmed) {
      leads.push({ phone: trimmed, source: 'manual_dashboard' });
    }
  }

  const result = scraper.addLeadsToQueue(leads);
  res.redirect(`/?added=${result.added}`);
});

app.post('/api/leads/shield-past', (req, res) => {
  const numbersText = req.body.pastNumbers || '';
  const lines = numbersText.split('\n');
  const numbersToShield = [];

  for (const line of lines) {
    const cleanDigits = line.replace(/\D/g, '');
    if (cleanDigits && cleanDigits.length >= 7) {
      numbersToShield.push(cleanDigits);
    }
  }

  const result = scraper.recordBulkSentPhones(numbersToShield);

  // Also update existing leads in DB if any matched
  try {
    const db = scraper.loadDatabase();
    for (const lead of db.leads) {
      if (scraper.isPhoneAlreadySent(lead.phone)) {
        lead.status = 'sent';
      }
    }
    scraper.saveDatabase(db);
  } catch (e) {}

  res.redirect(`/?shielded=true&count=${result.added}`);
});

app.post('/api/queue/pause', (req, res) => {
  queue.pauseQueue();
  res.redirect('/?paused=true');
});

app.post('/api/queue/resume', (req, res) => {
  queue.resumeQueue();
  res.redirect('/?resumed=true');
});

app.post('/api/scraper/pause', (req, res) => {
  scraper.pauseScraper();
  res.redirect('/?scraper_paused=true');
});

app.post('/api/scraper/resume', (req, res) => {
  scraper.resumeScraper();
  res.redirect('/?scraper_resumed=true');
});

app.post('/api/scraper/trigger-free-form', async (req, res) => {
  try {
    await scraper.triggerFreeWebScraper({ targetCount: 25 });
  } catch (err) {
    console.error('Free Scraper Error:', err);
  }
  res.redirect('/?scraper=free_triggered');
});

app.post('/api/scraper/trigger-form', async (req, res) => {
  try {
    await scraper.triggerApifyLeadDiscovery();
  } catch (err) {
    console.error('Apify Scraper Error:', err);
  }
  res.redirect('/?scraper=apify_triggered');
});

// Anti-Sleep Keep-Alive Engine (Prevents Render Free tier from spinning down after 15 mins of inactivity)
function initKeepAlive() {
  if (detectedBaseUrl) {
    startKeepAliveEngine(detectedBaseUrl);
  } else {
    console.log('💡 [Keep-Alive] Waiting for first inbound request or RENDER_EXTERNAL_URL to lock target URL...');
  }
}

/**
 * Start Server & WhatsApp Client
 */
app.listen(PORT, '0.0.0.0', () => {
  console.log(`\n==============================================`);
  console.log(`🚀 Webify WhatsApp AI Bot running on Port ${PORT}`);
  console.log(`📲 Open http://localhost:${PORT}/qr to link WhatsApp`);
  console.log(`==============================================\n`);

  // 1. Start the 24/7 autonomous scraper engine immediately (Runs continuously non-stop!)
  scraper.start247ContinuousScraper().catch(e => console.error("24/7 Scraper Boot Error:", e.message));

  // 2. Start Anti-Sleep Keep-Alive Heartbeat (Pings public URL every 6 mins to prevent Render spin down)
  initKeepAlive();

  // 3. Initialize WhatsApp connection with single-worker guard
  let hasStartedQueueWorker = false;
  whatsapp.initWhatsApp(() => {
    if (!hasStartedQueueWorker) {
      hasStartedQueueWorker = true;
      console.log('🤖 [Autonomous Engine] WhatsApp linked! Starting Queue Worker (Single Instance)...');
      queue.startQueueWorker(whatsapp);
    } else {
      console.log('⚡ [WhatsApp Reconnected] Queue Worker is already active.');
    }
  });
});
