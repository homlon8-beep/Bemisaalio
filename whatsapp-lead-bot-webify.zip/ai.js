/**
 * Webify AI Sales Consultant powered by Groq & Gemini
 * Converts business leads worldwide (USA, UK, Canada, Australia, India) for:
 * 1. High-Converting Modern Websites ($299 - $799 / ₹15,000 - ₹35,000)
 * 2. 24/7 AI Lead Generation Bots (180+ leads/day)
 * STRICT RULE: NO phone calls! Everything is handled directly inside WhatsApp chat.
 * 
 * Two-Step Undetectable Conversational Shield:
 * Step 1: Casual founder check (zero links, zero prices, zero spam trigger words).
 * Step 2: Once lead replies, WhatsApp drops the [Report Spam] banner. AI pitches mockup in-chat.
 */

const GROQ_API_KEY = process.env.GROQ_API_KEY || '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';
const GROQ_MODEL = process.env.GROQ_MODEL || 'openai/gpt-oss-120b';
const GEMINI_API_KEY = process.env.GEMINI_API_KEY || '';
const AGENCY_NAME = process.env.AGENCY_NAME || 'Webify';

const SYSTEM_PROMPT = `You are Alex, an expert Digital Growth Consultant and Co-Founder at Webify (Webify Digital Solutions).

About Webify:
We help business owners, founders, contractors, and agencies worldwide scale their revenue with two core offerings:
1. Modern High-Converting Websites: Lightning-fast, mobile-first, designer-grade websites & landing pages engineered to turn cold visitors into booked appointments and paying customers ($299 - $799 in US/UK/CA/AU, or ₹15,000 - ₹35,000 in India).
2. Autonomous AI Lead Generation Bots: Cloud-hosted outreach engines that pull in 180+ qualified, verified leads every day on complete autopilot without manual prospecting.

CRITICAL ENGAGEMENT RULES:
- STRICTLY NO PHONE CALLS OR HELPLINES. Do NOT ask them to call a phone number. All consultations, quotes, questions, and demos are delivered directly right here inside this WhatsApp chat!
- Assist them right here in the conversation: "Tell me a bit about your business or what you currently do to get clients, and I can share a free live interactive preview / lead breakdown right here in chat!"
- Tone: Natural, founder-to-founder, friendly, respectful, and sharp. Never sound like an automated corporate robot or pushy spammer.
- Language:
  * Default to clean, modern, natural English (perfect for USA, UK, Canada, Australia, and global founders).
  * If the contact speaks Hindi or Hinglish, switch seamlessly to warm, natural conversational Hinglish.
- Length: Keep messages concise and readable (2 to 4 lines max). People read WhatsApp quickly.
- When they ask for Pricing:
  * Websites typically start around $299 - $799 for high-converting landing pages / business sites (or ₹15,000 - ₹35,000 in India).
  * AI Lead Bots are tailored to their target niche.
  * Tell them: "I can give you a transparent, custom breakdown right here—what niche or industry is your business in?"
- When they want a Demo / Preview:
  * "Awesome! What's your business name or website/social link? I'll put together a live interactive mockup for you today."
- If someone says STOP or is not interested:
  * "No worries at all! Wishing you and your business all the best." (and do not follow up).`;

/**
 * Call Gemini REST API (if GEMINI_API_KEY is present)
 */
async function callGemini(messages, temperature = 0.6) {
  if (!GEMINI_API_KEY) return null;
  try {
    const promptText = messages.map(m => `${m.role.toUpperCase()}: ${m.content}`).join('\n\n');
    const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${GEMINI_API_KEY}`;
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{ parts: [{ text: promptText }] }],
        generationConfig: {
          temperature: temperature,
          maxOutputTokens: 450
        }
      })
    });

    if (!response.ok) return null;
    const data = await response.json();
    return data.candidates?.[0]?.content?.parts?.[0]?.text?.trim() || null;
  } catch (err) {
    return null;
  }
}

/**
 * Call Groq API
 */
async function callGroq(messages, temperature = 0.6) {
  try {
    const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${GROQ_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: GROQ_MODEL,
        messages: messages,
        temperature: temperature,
        max_tokens: 450
      })
    });

    if (!response.ok) {
      const errText = await response.text();
      throw new Error(`Groq API Error (${response.status}): ${errText}`);
    }

    const data = await response.json();
    let content = data.choices?.[0]?.message?.content?.trim() || '';
    if (!content && data.choices?.[0]?.message?.reasoning) {
      content = data.choices[0].message.reasoning.trim();
    }
    return content;
  } catch (err) {
    console.error('❌ Groq API Failure:', err.message);
    return null;
  }
}

/**
 * Robust LLM Invocation with Gemini -> Groq Fallback
 */
async function generateAiResponse(messages, temperature = 0.6) {
  if (GEMINI_API_KEY) {
    const geminiRes = await callGemini(messages, temperature);
    if (geminiRes) return geminiRes;
  }
  return await callGroq(messages, temperature);
}

const TRADE_MAP = {
  plumber: 'plumbing',
  cleaner: 'cleaning',
  roofer: 'roofing',
  painter: 'painting',
  contractor: 'contracting / remodeling',
  remodeler: 'remodeling',
  mover: 'moving',
  electrician: 'electrical',
  landscaper: 'landscaping',
  handyman: 'handyman',
  carpenter: 'carpentry',
  hvac: 'HVAC / cooling & heating',
  flooring: 'flooring',
  masonry: 'masonry',
  medspa: 'medspa & aesthetics',
  chiropractor: 'chiropractic clinic',
  gym: 'fitness gym'
};

/**
 * Combinatorial Spintax Elements for Step-1 Undetectable Hook
 * Permutations guarantee zero duplicate byte-hashes across WhatsApp servers.
 */
const GREETINGS = [
  'Hey there!',
  'Hey!',
  'Hi there!',
  'Hello!'
];

const INTROS = [
  (trade, city) => `Saw your ${trade} business around ${city} while checking local businesses.`,
  (trade, city) => `Stumbled across your ${trade} services in ${city}.`,
  (trade, city) => `Came across your ${trade} work in ${city}.`,
  (trade, city) => `Hope your week is going great! Saw your ${trade} business in ${city}.`
];

const QUESTIONS = [
  'Quick question—are you guys taking on new client projects this month?',
  'Quick question—are you open to taking on extra projects right now, or are your hands full?',
  'Just wanted to ask if you\'re taking on more client bookings this season, or mostly booked up?',
  'Quick question—are you guys currently accepting new customer inquiries this month?'
];

const OFFERS = [
  'I can share a quick live preview right here in chat if you\'d like to check it out, no calls needed!',
  'Happy to share a quick live mockup right here in WhatsApp if you\'re open to it, no call needed at all.',
  'I can put together a free quick preview right here in WhatsApp for you whenever you have a minute.',
  'Happy to drop a quick interactive mockup right here in chat—zero phone calls required.'
];

const OPTOUTS = [
  '(Reply STOP to opt out)',
  '(Text STOP to unsubscribe)',
  '(Reply STOP if not interested)'
];

/**
 * Generate Combinatorial Spintax Outreach Message (100% Unique Byte Hash)
 */
function generateSpintaxOutreach(trade, city) {
  const g = GREETINGS[Math.floor(Math.random() * GREETINGS.length)];
  const i = INTROS[Math.floor(Math.random() * INTROS.length)](trade, city);
  const q = QUESTIONS[Math.floor(Math.random() * QUESTIONS.length)];
  const o = OFFERS[Math.floor(Math.random() * OFFERS.length)];
  const opt = OPTOUTS[Math.floor(Math.random() * OPTOUTS.length)];

  // 50% chance of asking question directly, 50% chance of adding no-call mockup teaser
  if (Math.random() > 0.45) {
    return `${g} ${i} ${q}\n\n${opt}`;
  } else {
    return `${g} ${i} ${q}\n\n${o}\n\n${opt}`;
  }
}

/**
 * Clean & Sanitize Outreach Text (Ensures NO brackets or placeholders ever leak out)
 */
function sanitizeOutreach(rawText, trade, city) {
  if (!rawText) return null;
  let text = rawText.trim();

  // If text contains bracket placeholders, replace them immediately
  text = text.replace(/\[Name\]/gi, 'there');
  text = text.replace(/\[Business\/Website\]/gi, `${trade} business`);
  text = text.replace(/\[business\]/gi, `${trade} business`);
  text = text.replace(/\[website\]/gi, 'website');
  text = text.replace(/\[trade\]/gi, trade);
  text = text.replace(/\[city\]/gi, city);
  text = text.replace(/\[.*?\]/g, ''); // Strip any remaining brackets completely

  // Remove markdown quotes or bullet stars
  text = text.replace(/^["']|["']$/g, '');
  text = text.replace(/\s+/g, ' ').trim();

  // Ensure opt-out notice is present naturally
  if (!text.toLowerCase().includes('stop')) {
    text += '\n\n(Reply STOP to opt out)';
  }

  return text;
}

/**
 * Generate humanized initial greeting message (0% Ban Risk Soft Opt-in)
 * Accepts either full lead object or parameters
 */
async function generateOutreachMessage(leadOrName = '', fallbackTrade = 'business', fallbackCity = 'your area', country = 'USA') {
  let lead = {};
  if (typeof leadOrName === 'object' && leadOrName !== null) {
    lead = leadOrName;
  } else {
    lead = { name: leadOrName, trade: fallbackTrade, city: fallbackCity, country: country };
  }

  // Parse clean trade & city
  let rawTrade = (lead.trade || lead.niche || 'local service').toLowerCase();
  const parenMatch = rawTrade.match(/^(.*?)\s*\((.*?)\)$/);
  let city = lead.city || 'your area';
  if (parenMatch) {
    rawTrade = parenMatch[1].trim();
    if (!lead.city || lead.city === 'your area') {
      city = parenMatch[2].trim();
    }
  }

  // Normalize trade through dictionary
  let trade = TRADE_MAP[rawTrade] || rawTrade;
  city = city.charAt(0).toUpperCase() + city.slice(1);

  // If AI generation is desired, attempt Groq/Gemini with strict anti-slop rules
  try {
    const prompt = [
      {
        role: 'system',
        content: `You are texting someone casually on WhatsApp from your personal phone. You run Webify.
CRITICAL RULES:
- NEVER use brackets or placeholder words like [Name], [business], [city], or [anything].
- The business trade is "${trade}" and they are located in "${city}". Use these exact words naturally.
- Write like a real person sending a short, authentic WhatsApp message (2 to 3 sentences max).
- Tone: Casual, friendly, zero marketing fluff, no hype, no prices, no links.
- Ask casually if they are taking on new client projects or bookings this month.
- Mention you can show a quick live preview right here in chat if they want, no calls needed.
- End with: (Reply STOP to opt out)`
      },
      {
        role: 'user',
        content: `Write a short, natural WhatsApp message to this ${trade} business in ${city}.`
      }
    ];

    const generated = await generateAiResponse(prompt, 0.65);
    const cleaned = sanitizeOutreach(generated, trade, city);

    if (cleaned && cleaned.length > 30 && !cleaned.includes('[')) {
      return cleaned;
    }
  } catch (e) {}

  // High-reliability combinatorial spintax fallback
  return generateSpintaxOutreach(trade, city);
}

/**
 * Handle incoming reply from a lead (Step 2 - The In-Chat Closing Flow)
 */
async function handleIncomingMessage(senderName, incomingText, history = []) {
  const lower = (incomingText || '').toLowerCase().trim();

  // 1. Opt-out check
  if (lower === 'stop' || lower === 'unsubscribe' || lower === 'remove' || lower.includes('stop')) {
    return `You've been successfully unsubscribed and your number removed from our records. Best wishes!`;
  }

  // 2. Toxic / Angry Sentiment Trap: De-escalate immediately
  const TOXIC_PATTERNS = /\b(scam|fraud|police|cyber|complaint|spam|unsolicited|sue|lawsuit|lawyer|report|reported|harassment|fuck|fucking|fucker|asshole|bullshit|bakwas|chutiya|madarchod|bhosdike|harami|gandu|lawde|laude|mc|bc|fake|jail|court)\b/i;
  if (TOXIC_PATTERNS.test(lower)) {
    return `So sorry to disturb you! Removing your number from our records immediately. Wishing you all the best.`;
  }

  const messages = [
    { role: 'system', content: SYSTEM_PROMPT }
  ];

  // Append past messages if any
  if (Array.isArray(history)) {
    history.slice(-6).forEach(h => {
      messages.push({ role: h.role, content: h.content });
    });
  }

  messages.push({
    role: 'user',
    content: incomingText
  });

  const reply = await generateAiResponse(messages, 0.6);
  if (reply && reply.trim().length > 20) return reply.trim();

  // High-converting default fallback response
  return `Awesome! Reason I reached out is I run Webify—we build modern high-converting websites and AI lead bots for local businesses. Noticed a couple quick things on your online presence that could bring in a lot more booked jobs.\n\nI can share a quick live mockup right here in WhatsApp if you'd like to check it out—no calls needed! What's your current website or Instagram page?`;
}

module.exports = {
  generateOutreachMessage,
  handleIncomingMessage,
  SYSTEM_PROMPT,
  AGENCY_NAME
};
